#include<stdio.h>

// write a program to add, subtract, divide , multiply two number. 

int main(){
    int a = 2;
    int b = 3;
    printf("%d + %d = %d\n",a,b,a+b);
    printf("%d - %d = %d\n",a,b,a-b);
    printf("%d / %d = %d\n",a,b,a/b);
    printf("%d * %d = %d\n",a,b,a*b);

return 0;
}