#include<stdio.h>

int main() {
    return 1000;
}

// a.out is binary code
// a.exe is binary code

// Linux / MacOS - echo $?
// Windows PowerShell - echo $LASTEXITCODE

// Install VSCode
// Install C/C++ Extension Pack
// gcc 
// Github Accounts
// Associate github accounts with your official Email IDs
// Linux / CMD / Terminal Cheatsheet
// Optional - Linux 