#include <stdio.h>

int main() {
    int count = 1;
    while (count <= 5) {
        printf("%d\n", count);
        count++;
    }
    return 0;
}
