#include <stdio.h>

int main() {
    int count = 1;
    do {
        printf("%d\n", count);
        count++;
    } while (count <= 5);
    return 0;
}
